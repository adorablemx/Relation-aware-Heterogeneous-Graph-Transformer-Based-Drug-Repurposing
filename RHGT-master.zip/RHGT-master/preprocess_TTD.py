#from transformers import *

from data import *
import gensim
from gensim.models import Word2Vec
from tqdm import tqdm
# from tqdm import tqdm_notebook as tqdm   # Comment this line if using jupyter notebook
import random
import networkx as nx
import argparse
import pandas as pd
import numpy as np
from itertools import chain
import dill
from pyHGT.data import *

parser = argparse.ArgumentParser(description='Preprocess OAG (CS/Med/All) Data')

'''
    Dataset arguments
'''
parser.add_argument('--input_dir', type=str, default='data/ttd',
                    help='The address to store the original data directory.')
parser.add_argument('--output_dir', type=str, default='data/ttd',
                    help='The address to output the preprocessed graph.')
parser.add_argument('--cuda', type=int, default=0,
                    help='Avaiable GPU ID')
parser.add_argument('--domain', type=str, default='_CS',
                    help='CS, Medical or All: _CS or _Med or (empty)')
parser.add_argument('--citation_bar', type=int, default=1,
                    help='Only consider papers with citation larger than (2020 - year) * citation_bar')

args = parser.parse_args()

edge_type_graph = nx.Graph()

ednode = pd.read_csv(args.input_dir + '/type_node.csv', encoding='utf-8')

ednode_list = list(chain.from_iterable(ednode.values.tolist()))
#print(ednode_list)
edge_type_graph.add_nodes_from(ednode_list)

edty = pd.read_csv(args.input_dir + '/type_edge.csv', encoding='utf-8')
edty_list = edty.values.tolist()

for i in range(len(edty_list)):
    edge_type_graph.add_edge(edty_list[i][0],edty_list[i][1],weight=edty_list[i][2])

dill.dump(edge_type_graph, open(args.output_dir + '/graph_edgetype_ttd.pk', 'wb')) 




graph = Graph()

c_g_edge = pd.read_csv(args.input_dir + '/dr_e1_t.csv', encoding='utf-8')
c_g_list = c_g_edge.values.tolist()
max_edgetype_nums = 0

for i in range(len(c_g_list)):
    source = {'id': c_g_list[i][0], 'type': 'chemical'}
    target = {'id': c_g_list[i][2], 'type': 'gene'}
    if c_g_list[i][1] not in graph.edge_types:
        graph.edge_types.append(c_g_list[i][1])
        if max_edgetype_nums < len(c_g_list[i][1].split('|')):
            max_edgetype_nums = len(c_g_list[i][1].split('|'))
    graph.add_edge(source, target, weight=c_g_list[i][1], relation_type = c_g_list[i][1], directed = False)

graph.max_edgetype_nums = max_edgetype_nums
g_d_edge = pd.read_csv(args.input_dir + '/t_e2_d.csv', encoding='utf-8')
g_d_list = g_d_edge.values.tolist()

for i in range(len(g_d_list)):
    source = {'id': g_d_list[i][0], 'type': 'gene'}
    target = {'id': g_d_list[i][2], 'type': 'disease'}
    if g_d_list[i][1] not in graph.edge_types:
        graph.edge_types.append(g_d_list[i][1])
    graph.add_edge(source, target, weight=g_d_list[i][1], relation_type = g_d_list[i][1], directed = False)

ttd_vec = open(args.input_dir + '/vec_ttd_256.txt', 'r').readlines()


for i in ttd_vec:
    i = i.strip().split()
    graph.fea_id.append(graph.nodes.index(i[0]))
    graph.node_feature.append(np.array(list(map(lambda x:float(x), i[1:])), dtype=np.float)) 

dill.dump(graph, open(args.output_dir + '/graph_ttd_256.pk', 'wb'))

graph = renamed_load(open(os.path.join(args.output_dir + '/graph_ttd_256.pk'), 'rb'))

data_true = pd.read_csv(os.path.join(args.input_dir + '/c_g_d_true.csv'))
data_true_list = data_true.values.tolist()

data_false = pd.read_csv(os.path.join(args.input_dir + '/c_g_d_false.csv'))
data_false_list = data_false.values.tolist()

del data_true
del data_false

random.shuffle(data_true_list)
random.shuffle(data_false_list)

train_size_true = int(0.1 * len(data_true_list))
val_size_true = int(0.7 * len(data_true_list))
test_size_true = len(data_true_list)-train_size_true - val_size_true

train_size_false = int(0.1 * len(data_false_list))
val_size_false = int(0.7 * len(data_false_list))
test_size_false = len(data_false_list)-train_size_false - val_size_false

graph.train_pairs = data_true_list[0:train_size_true] + data_false_list[0:train_size_false]
graph.val_pairs = data_true_list[train_size_true:train_size_true+val_size_true] + data_false_list[train_size_false:train_size_false+val_size_false]
graph.test_pairs = data_true_list[train_size_true+val_size_true:] + data_false_list[train_size_false+val_size_false:]

del data_true_list
del data_false_list

random.shuffle(graph.train_pairs)#[n1,e1,n2,n3,label]
random.shuffle(graph.val_pairs)
random.shuffle(graph.test_pairs)

dill.dump(graph, open(args.output_dir + '/graph_ttd_256_1.pk', 'wb'))