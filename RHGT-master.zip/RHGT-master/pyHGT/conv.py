import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Variable
from torch_geometric.nn import GCNConv, GATConv
from torch_geometric.nn.conv import MessagePassing
from torch_geometric.nn.inits import glorot, uniform
from torch_geometric.utils import softmax, remove_self_loops, add_self_loops
import math


def zeros(tensor):
    if tensor is not None:
        tensor.data.fill_(0)

def add_self_edge_attr_loops(edge_attr, num_nodes=None):
    dtype, device = edge_attr.dtype, edge_attr.device
    loop = torch.ones(num_nodes, dtype=dtype, device=device)
    edge_attr = torch.cat([edge_attr, loop], dim=0)

    return edge_attr

class GATConv2(MessagePassing):
    def __init__(self,
                 in_channels,
                 out_channels,
                 n_heads=1,
                 negative_slope=0.2,
                 dropout=0.,
                 bias=True):
        super(GATConv2, self).__init__(aggr='add')  # "Add" aggregation.

        self.in_channels = in_channels
        self.out_channels = out_channels
        self.n_heads = n_heads
        self.negative_slope = negative_slope
        self.dropout = dropout

        self.weight = nn.Parameter(torch.Tensor(in_channels, n_heads * out_channels))  # \theta
        self.att = nn.Parameter(torch.Tensor(1, n_heads, 2 * out_channels))  # \alpha: rather than separate into two parts

        if bias:
            self.bias = nn.Parameter(torch.Tensor(out_channels))
        else:
            self.register_parameter('bias', None)

        self.reset_parameters()

    def reset_parameters(self):
        glorot(self.weight)
        glorot(self.att)
        zeros(self.bias)

    def forward(self, x, edge_index, edge_type_weight, size=None):
        # 1. Linearly transform node feature matrix (XΘ)
        x = torch.mm(x, self.weight).view(-1, self.n_heads, self.out_channels)  # N x H x emb(out)
        
        # 2. Add self-loops to the adjacency matrix (A' = A + I)
        if size is None and torch.is_tensor(x):
            edge_index, _ = remove_self_loops(edge_index)  # 2 x E
            edge_index, _ = add_self_loops(edge_index, num_nodes=x.size(0))  # 2 x (E+N)
            edge_type_weight = add_self_edge_attr_loops(edge_type_weight, x.size(0))

        # 3. Start propagating messages  
        return self.propagate(edge_index, x=x, edge_type_weight=edge_type_weight)  # 2 x (E+N), N x H x emb(out), None

    def message(self, x_i, x_j, edge_index_i, edge_type_weight):  # Compute normalization (concatenate + softmax)

        x_i = x_i.view(-1, self.n_heads, self.out_channels)
        alpha = (torch.cat([x_i, x_j], dim=-1) * self.att).sum(dim=-1)  # (E+N) x H x (emb(out)+ emb(out))
        
        edge_type_weight = edge_type_weight.unsqueeze(-1).repeat(1,self.n_heads)
        
        alpha = edge_type_weight * alpha
        alpha = F.leaky_relu(alpha, self.negative_slope)  # LeakReLU only changes those negative.
        alpha = softmax(alpha, edge_index_i)  # Computes a sparsely evaluated softmax

        if self.training and self.dropout > 0:
            alpha = F.dropout(alpha, p=self.dropout, training=True)

        return x_j * alpha.view(-1, self.n_heads, 1)
        # each row is norm(embedding) vector for each edge_index pair (detail in the following)

    def update(self, aggr_out):  # 4. Return node embeddings (average heads)
        # Based on the directed graph, Node 0 gets message from three edges and one self_loop 
        # for Node 1, 2, 3: since they do not get any message from others, so only self_loop

        aggr_out = aggr_out.mean(dim=1)  # to average multi-head

        if self.bias is not None:
            aggr_out = aggr_out + self.bias
        return F.gelu(aggr_out)

class HTNConv(MessagePassing):
    def __init__(self, in_dim, out_dim, num_types, num_relations, n_heads, dropout = 0.2, use_norm = True, **kwargs):
        super(HTNConv, self).__init__(aggr='add', **kwargs)

        self.in_dim        = in_dim
        self.out_dim       = out_dim
        self.num_types     = num_types
        self.num_relations = num_relations
        self.total_rel     = num_types * num_relations * num_types
        self.n_heads       = n_heads
        self.d_k           = out_dim // n_heads
        self.sqrt_dk       = math.sqrt(self.d_k)
        self.use_norm      = use_norm
        self.att           = None
        
        
        self.k_linears   = nn.ModuleList()
        self.q_linears   = nn.ModuleList()
        self.v_linears   = nn.ModuleList()
        self.a_linears   = nn.ModuleList()
        self.as_linears  = nn.ModuleList()
        self.at_linears  = nn.ModuleList()
        self.m_linears   = nn.ModuleList()
        self.norms       = nn.ModuleList()
        
        for t in range(num_types):
            self.k_linears.append(nn.Linear(in_dim,   out_dim))
            self.q_linears.append(nn.Linear(in_dim,   out_dim))
            self.v_linears.append(nn.Linear(in_dim,   out_dim))
            self.a_linears.append(nn.Linear(out_dim,  out_dim))
            self.as_linears.append(nn.Linear(out_dim,  out_dim))
            self.at_linears.append(nn.Linear(out_dim,  out_dim))
            self.m_linears.append(nn.Linear(out_dim,  out_dim))
            if use_norm:
                self.norms.append(nn.LayerNorm(out_dim))
        '''
            TODO: make relation_pri smaller, as not all <st, rt, tt> pair exist in meta relation list.
        '''
        self.skip           = nn.Parameter(torch.ones(num_types))
        self.drop           = nn.Dropout(dropout)
        
    def forward(self, node_inp, node_type, edge_index, edge_type, relation_type_fea):
        
        return self.propagate(edge_index, node_inp=node_inp, node_type=node_type, \
                              edge_type=edge_type, relation_type_fea=relation_type_fea)

    def message(self, edge_index_i, node_inp_i, node_inp_j, node_type_i, node_type_j, edge_type, relation_type_fea):
        '''
            j: source, i: target; <j, i>
        '''
        data_size = edge_index_i.size(0)
        '''
            Create Attention and Message tensor beforehand.
        '''
        res_att     = torch.zeros(data_size, self.n_heads).to(node_type_i.device)
        res_msg     = torch.zeros(data_size, self.n_heads, self.d_k).to(node_type_i.device)
        
        for source_type in range(self.num_types):
            sb = (node_type_j == int(source_type))
            k_linear = self.k_linears[source_type]
            v_linear = self.v_linears[source_type]
            as_linear = self.as_linears[source_type]
            m_linear = self.m_linears[source_type]
            for target_type in range(self.num_types):
                tb = (node_type_i == int(target_type)) & sb
                q_linear = self.q_linears[target_type]
                at_linear = self.at_linears[target_type]
                for relation_type in range(self.num_relations):
                    '''
                        idx is all the edges with meta relation <source_type, relation_type, target_type>
                    '''
                    idx = (edge_type == int(relation_type)) & tb
                    if idx.sum() == 0:
                        continue
                    '''
                        Get the corresponding input node representations by idx.
                        Add tempotal encoding to source representation (j)
                    '''
                    target_node_vec = node_inp_i[idx]
                    source_node_vec = node_inp_j[idx]
                    relation_type_vec = relation_type_fea[relation_type]
                    '''
                        Step 1:  Attention
                    '''
                    q_mat = q_linear(target_node_vec).view(-1, self.n_heads, self.d_k)
                    k_mat = k_linear(source_node_vec).view(-1, self.n_heads, self.d_k)

                    as_mat = as_linear(relation_type_vec).view(-1, self.n_heads, self.d_k).unsqueeze(-1)
                    at_mat = at_linear(relation_type_vec).view(-1, self.n_heads, self.d_k).unsqueeze(-1)
                    
                    w_att = torch.matmul(as_mat, at_mat.transpose(-1,-2))
                    
                    k_mat = torch.matmul(k_mat.unsqueeze(-1).transpose(-1,-2), w_att)
                    
                    res_att[idx] = torch.matmul(k_mat , q_mat.unsqueeze(-1)).squeeze(-1).squeeze(-1) / self.sqrt_dk
                    '''
                        Step 2: Message Passing
                    '''
                    v_mat = v_linear(source_node_vec).view(-1, self.n_heads, self.d_k)
                    m_mat = m_linear(relation_type_vec).view(-1, self.n_heads, self.d_k).unsqueeze(-1)
                    
                    w_msg = torch.matmul(m_mat, m_mat.transpose(-1,-2))

                    res_msg[idx] = torch.matmul(w_msg, v_mat.unsqueeze(-1)).squeeze(-1) 
        '''
            Softmax based on target node's id (edge_index_i). Store attention value in self.att for later visualization.
        '''
        
        self.att = softmax(res_att, edge_index_i)
        res = res_msg * self.att.view(-1, self.n_heads, 1)
        del res_att, res_msg
        return res.view(-1, self.out_dim)


    def update(self, aggr_out, node_inp, node_type):
        '''
            Step 3:  Aggregation
        '''
        aggr_out = F.gelu(aggr_out)
        res = torch.zeros(aggr_out.size(0), self.out_dim).to(node_type.device)
        for target_type in range(self.num_types):
            idx = (node_type == int(target_type))
            if idx.sum() == 0:
                continue
            trans_out = self.drop(self.a_linears[target_type](aggr_out[idx]))
            '''
                Add skip connection with learnable weight self.skip[t_id]
            '''
            alpha = torch.sigmoid(self.skip[target_type])
            if self.use_norm:
                res[idx] = self.norms[target_type](trans_out * alpha + node_inp[idx] * (1 - alpha))
            else:
                res[idx] = trans_out * alpha + node_inp[idx] * (1 - alpha)
        return res

    def __repr__(self):
        return '{}(in_dim={}, out_dim={}, num_types={}, num_types={})'.format(
            self.__class__.__name__, self.in_dim, self.out_dim,
            self.num_types, self.num_relations)


class HTEConv(MessagePassing):
    def __init__(self, in_dim, out_dim, num_types, num_relations, n_heads, dropout = 0.2, use_norm = True, **kwargs):
        super(HTEConv, self).__init__(aggr='add', **kwargs)

        self.in_dim        = in_dim
        self.out_dim       = out_dim
        self.num_types     = num_types
        self.num_relations = num_relations
        self.total_rel     = num_types * num_relations * num_types
        self.n_heads       = n_heads
        self.d_k           = out_dim // n_heads
        self.sqrt_dk       = math.sqrt(self.d_k)
        self.use_norm      = use_norm
        self.att           = None
        
        
        self.k_linears   = nn.ModuleList()
        self.q_linears   = nn.ModuleList()
        self.v_linears   = nn.ModuleList()
        self.a_linears   = nn.ModuleList()
        self.an_linears  = nn.ModuleList()
        self.m_linears   = nn.ModuleList()
        self.norms       = nn.ModuleList()
        
        for t in range(num_types):
            self.k_linears.append(nn.Linear(in_dim,   out_dim))
            self.q_linears.append(nn.Linear(in_dim,   out_dim))
            self.v_linears.append(nn.Linear(in_dim,   out_dim))
            self.a_linears.append(nn.Linear(out_dim,  out_dim))
            if use_norm:
                self.norms.append(nn.LayerNorm(out_dim))
        for t in range(num_relations):
            self.an_linears.append(nn.Linear(in_dim,   out_dim))
            self.m_linears.append(nn.Linear(in_dim,   out_dim))
            if use_norm:
                self.norms.append(nn.LayerNorm(out_dim))

        '''
            TODO: make relation_pri smaller, as not all <st, rt, tt> pair exist in meta relation list.
        '''
        self.alpha          = nn.Parameter(torch.ones(num_types))
        self.drop           = nn.Dropout(dropout)
        
        
    def forward(self, node_inp, node_type, edge_index, edge_type, relation_type_fea):
        return self.propagate(edge_index, node_inp=node_inp, node_type=node_type, \
                              edge_type=edge_type, relation_type_fea=relation_type_fea)

    def message(self, edge_index_i, node_inp_i, node_inp_j, node_type_i, node_type_j, edge_type, relation_type_fea):
        '''
            j: source, i: target; <j, i>
        '''
        data_size = edge_index_i.size(0)
        '''
            Create Attention and Message tensor beforehand.
        '''
        res_att     = torch.zeros(data_size, self.n_heads).to(node_type_i.device)
        res_msg     = torch.zeros(data_size, self.n_heads, self.d_k).to(node_type_i.device)
        
        for source_type in range(self.num_types):
            sb = (node_type_j == int(source_type))
            k_linear = self.k_linears[source_type]
            v_linear = self.v_linears[source_type] 
            for target_type in range(self.num_types):
                tb = (node_type_i == int(target_type)) & sb
                q_linear = self.q_linears[target_type]
                for relation_type in range(self.num_relations):
                    an_linear = self.an_linears[relation_type]
                    m_linear = self.m_linears[relation_type]
                    '''
                        idx is all the edges with meta relation <source_type, relation_type, target_type>
                    '''
                    idx = (edge_type == int(relation_type)) & tb
                    if idx.sum() == 0:
                        continue
                    '''
                        Get the corresponding input node representations by idx.
                        Add tempotal encoding to source representation (j)
                    '''
                    target_node_vec = node_inp_i[idx]
                    source_node_vec = node_inp_j[idx]
                    '''
                        Step 1:  Attention
                    '''
                    q_mat = q_linear(target_node_vec).view(-1, self.n_heads, self.d_k)
                    k_mat = k_linear(source_node_vec).view(-1, self.n_heads, self.d_k)
                    
                    ans_mat = an_linear(relation_type_fea[source_type]).view(-1, self.n_heads, self.d_k).unsqueeze(-1)
                    ant_mat = an_linear(relation_type_fea[target_type]).view(-1, self.n_heads, self.d_k).unsqueeze(-1)
                    
                    w_att = torch.matmul(ans_mat, ant_mat.transpose(-1,-2))
                    
                    k_mat = torch.matmul(k_mat.unsqueeze(-1).transpose(-1,-2), w_att)
                    
                    res_att[idx] = torch.matmul(k_mat , q_mat.unsqueeze(-1)).squeeze(-1).squeeze(-1) / self.sqrt_dk
                    '''
                        Step 2: Message Passing
                    '''
                    v_mat = v_linear(source_node_vec).view(-1, self.n_heads, self.d_k)
                    m_mat = m_linear(relation_type_fea[source_type]).view(-1, self.n_heads, self.d_k).unsqueeze(-1)
                    
                    w_msg = torch.matmul(m_mat, m_mat.transpose(-1,-2))
                    
                    res_msg[idx] = torch.matmul(w_msg, v_mat.unsqueeze(-1)).squeeze(-1)   
        '''
            Softmax based on target node's id (edge_index_i). Store attention value in self.att for later visualization.
        '''
        self.att = softmax(res_att, edge_index_i)
        
        res = res_msg * self.att.view(-1, self.n_heads, 1)
        del res_att, res_msg
        return res.view(-1, self.out_dim)


    def update(self, aggr_out, node_inp, node_type):
        '''
            Step 3:  Aggregation
        '''
        aggr_out = F.gelu(aggr_out)
        res = torch.zeros(aggr_out.size(0), self.out_dim).to(node_inp.device)
        for target_type in range(self.num_types):
            idx = (node_type == int(target_type))
            if idx.sum() == 0:
                continue
            trans_out = self.drop(self.a_linears[target_type](aggr_out[idx]))
            '''
                Add skip connection with learnable weight self.skip[t_id]
            '''
            alpha = torch.sigmoid(self.alpha[target_type])
            
            if self.use_norm:
                res[idx] = self.norms[target_type](trans_out * alpha + node_inp[idx] * (1 - alpha))
            else:
                res[idx] = trans_out * alpha + node_inp[idx] * (1 - alpha)
        return res

    def __repr__(self):
        return '{}(in_dim={}, out_dim={}, num_types={}, num_types={})'.format(
            self.__class__.__name__, self.in_dim, self.out_dim,
            self.num_types, self.num_relations)    
    
    
class GeneralConv(nn.Module):
    def __init__(self, conv_name, in_hid, out_hid, num_types, num_relations, n_heads, dropout, use_norm = True):
        super(GeneralConv, self).__init__()
        self.conv_name = conv_name
        if self.conv_name == 'htn':
            self.base_conv = HTNConv(in_hid, out_hid, num_types, num_relations, n_heads, dropout, use_norm)
        elif self.conv_name == 'hte':
            self.base_conv = HTEConv(in_hid, out_hid, num_types, num_relations, n_heads, dropout, use_norm)
        elif self.conv_name == 'gcn':
            self.base_conv = GCNConv(in_hid, out_hid)
        elif self.conv_name == 'gat':
            self.base_conv = GATConv(in_hid, out_hid // n_heads, heads=n_heads)
    def forward(self, meta_xs, node_type, edge_index, edge_type, relation_type_fea):
        if self.conv_name == 'htn':
            return self.base_conv(meta_xs, node_type, edge_index, edge_type, relation_type_fea)
        elif self.conv_name == 'hte':
            return self.base_conv(meta_xs, node_type, edge_index, edge_type, relation_type_fea)
        elif self.conv_name == 'gcn':
            return self.base_conv(meta_xs, edge_index)
        elif self.conv_name == 'gat':
            return self.base_conv(meta_xs, edge_index)
    
