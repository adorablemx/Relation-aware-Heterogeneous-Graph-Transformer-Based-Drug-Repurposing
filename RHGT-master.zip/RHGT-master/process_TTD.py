import pandas as pd
import random
from collections import defaultdict
import numpy as np


#for ttd true/false
df_ge2d = pd.read_csv(r"data/ttd/t_e2_d.csv")
df_ce1g = pd.read_csv(r"data/ttd/dr_e1_t.csv")
df_cd = pd.read_csv(r"data/ttd/dr_d.csv")

g_d_dict = {}
t_d_dict = {}
df_ge2dlist = df_ge2d.values.tolist()
for i in range(len(df_ge2dlist)):
	g_d_dict[(df_ge2dlist[i][0],df_ge2dlist[i][2])] = df_ge2dlist[i][1]
	t_d_dict.setdefault(df_ge2dlist[i][0], []).append(df_ge2dlist[i][2])

cg_e_dict = {}

df_ce1glist = df_ce1g.values.tolist()
for i in range(len(df_ce1glist)):
	cg_e_dict[(df_ce1glist[i][0],df_ce1glist[i][2])] = df_ce1glist[i][1]

c_d_list = []
df_cdlist = df_cd.values.tolist()
for i in range(len(df_cdlist)):
	c_d_list.append((df_cdlist[i][0],df_cdlist[i][1]))
	#cg_d_dict.setdefault((df_cgdlist[i][0],df_cgdlist[i][1]), []).append(df_cgdlist[i][2])

label_0 = []#false
label_1 = []#true
target = []
for dr_t,e1 in cg_e_dict.items():
	temp_true = []
	temp_false = []
	if dr_t[1] not in t_d_dict:
		if dr_t[1] not in target:
			target.append(dr_t[1])
			print(dr_t[1])
		continue
	for d in t_d_dict[dr_t[1]]:
		if (dr_t[0],d) in c_d_list:
			temp_true.append(d)
		else:
			temp_false.append(d)
	for d in temp_true:
		e2 = g_d_dict[(dr_t[1]),d]
		label_1.append([dr_t[0],e1,dr_t[1],e2,d,1])
	if len(temp_false)<len(temp_true):
		for d in temp_false:
			e2 = g_d_dict[(dr_t[1]),d]
			label_0.append([dr_t[0],e1,dr_t[1],e2,d,0])
	else:
		d_f = random.sample(temp_false,len(temp_true))
		for d in d_f:
			e2 = g_d_dict[(dr_t[1]),d]
			label_0.append([dr_t[0],e1,dr_t[1],e2,d,0])

out_label1 = pd.DataFrame(label_1)
out_label1.to_csv('data/ttd/c_g_d_true.csv',index=False,sep=",")

out_label0 = pd.DataFrame(label_0)
out_label0.to_csv('data/ttd/c_g_d_false.csv',index=False,sep=",")
print(target)